import React from 'react';

export class Home extends React.Component{
    constructor(){
        super();
        this.state = {

        };
    }
    render(){
        return null;
    }
}