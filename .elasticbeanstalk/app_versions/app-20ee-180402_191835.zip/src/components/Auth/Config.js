export default {
    region: 'us-east-1',
    IdentityPoolId: 'us-east-1:051d18f6-a6bf-4237-af95-33c0f3a45cc1',
    UserPoolId: 'us-east-1_yznBlsoTx',
    ClientId: '55lhidgnj7jtbo9vn0rrq3c0qa',
    poolData : {
        UserPoolId:  'us-east-1_yznBlsoTx', // Your user pool id here
        ClientId: '55lhidgnj7jtbo9vn0rrq3c0qa'
    }
}